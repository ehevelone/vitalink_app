// functions/reset_password.js

const db = require("./services/db");
const bcrypt = require("bcryptjs");

const CORS_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function reply(statusCode, body) {
  return {
    statusCode,
    headers: CORS_HEADERS,
    body: JSON.stringify(body),
  };
}

exports.handler = async (event) => {
  try {
    if (event.httpMethod === "OPTIONS") {
      return { statusCode: 200, headers: CORS_HEADERS, body: "" };
    }

    if (event.httpMethod !== "POST") {
      return reply(405, { success: false, error: "Method Not Allowed" });
    }

    let body = {};
    try {
      body = event.isBase64Encoded
        ? JSON.parse(Buffer.from(event.body, "base64").toString("utf8"))
        : JSON.parse(event.body || "{}");
    } catch {
      return reply(400, { success: false, error: "Invalid request body" });
    }

    console.log("📥 BODY:", body);

    const { emailOrPhone, code, newPassword, role } = body;

    if (!emailOrPhone || !code || !newPassword || !role) {
      console.log("❌ Missing fields");
      return reply(400, { success: false, error: "Missing required fields" });
    }

    if (role !== "users" && role !== "agents") {
      console.log("❌ Invalid role:", role);
      return reply(400, { success: false, error: "Invalid role" });
    }

    const email = String(emailOrPhone).trim().toLowerCase();

    const result = await db.query(
      `
      SELECT id, email, reset_code, reset_expires
      FROM ${role}
      WHERE LOWER(email) = $1
      LIMIT 1
      `,
      [email]
    );

    if (!result.rows.length) {
      console.log("❌ No account found for:", email);
      return reply(404, { success: false, error: "No account found" });
    }

    const user = result.rows[0];

    console.log("👤 DB USER:", user);

    const storedCode = String(user.reset_code ?? "").trim();
    const enteredCode = String(code ?? "").trim();

    console.log("🔐 Stored Code:", storedCode);
    console.log("🔐 Entered Code:", enteredCode);
    console.log("⏱ Expires:", user.reset_expires);

    if (storedCode.length === 0) {
      console.log("❌ No reset code in DB");
      return reply(400, { success: false, error: "No reset code found" });
    }

    // 🔥 FIXED COMPARISON (handles spaces, weird chars)
    const cleanStored = storedCode.replace(/\s/g, "");
    const cleanEntered = enteredCode.replace(/\s/g, "");

    if (cleanStored !== cleanEntered) {
      console.log("❌ Code mismatch");
      return reply(400, { success: false, error: "Invalid reset code" });
    }

    if (!user.reset_expires || new Date(user.reset_expires) < new Date()) {
      console.log("❌ Code expired");
      return reply(400, { success: false, error: "Reset code expired" });
    }

    const hashed = await bcrypt.hash(newPassword, 12);

    const update = await db.query(
      `
      UPDATE ${role}
      SET password_hash = $1,
          reset_code = NULL,
          reset_expires = NULL
      WHERE id = $2
      RETURNING id
      `,
      [hashed, user.id]
    );

    if (update.rowCount === 0) {
      console.log("❌ Password update failed");
      return reply(500, { success: false, error: "Password update failed" });
    }

    console.log(`✅ Password reset SUCCESS for ${user.email} (${role})`);

    return reply(200, { success: true });

  } catch (err) {
    console.error("❌ reset_password error:", err);
    return reply(500, { success: false, error: "Server error" });
  }
};