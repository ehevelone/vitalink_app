var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// functions/services/db.js
var require_db = __commonJS({
  "functions/services/db.js"(exports2, module2) {
    var { Pool } = require("pg");
    var pool = new Pool({
      connectionString: process.env.SUPABASE_URL,
      ssl: { rejectUnauthorized: false }
      // required for Supabase
    });
    var db2 = {
      query: (text, params) => pool.query(text, params)
    };
    module2.exports = db2;
  }
});

// functions/services/passwords.js
var require_passwords = __commonJS({
  "functions/services/passwords.js"(exports2, module2) {
    var bcrypt = require("bcryptjs");
    var crypto = require("crypto");
    function isBcryptHash(hash) {
      return /^\$2[aby]\$\d{2}\$/.test(String(hash || ""));
    }
    function isLegacySha256Hash(hash) {
      return /^[a-f0-9]{64}$/i.test(String(hash || "").trim());
    }
    function legacySha256(password) {
      return crypto.createHash("sha256").update(String(password || "")).digest("hex");
    }
    async function verifyPassword2(password, hash) {
      const storedHash = String(hash || "").trim();
      if (!password || !storedHash) {
        return { valid: false, legacy: false };
      }
      if (isBcryptHash(storedHash)) {
        return {
          valid: await bcrypt.compare(password, storedHash),
          legacy: false
        };
      }
      if (isLegacySha256Hash(storedHash)) {
        return {
          valid: legacySha256(password) === storedHash,
          legacy: true
        };
      }
      return { valid: false, legacy: false };
    }
    async function hashPassword2(password, rounds = 12) {
      return bcrypt.hash(password, rounds);
    }
    module2.exports = {
      hashPassword: hashPassword2,
      verifyPassword: verifyPassword2
    };
  }
});

// functions/services/agent-auth.js
var require_agent_auth = __commonJS({
  "functions/services/agent-auth.js"(exports2, module2) {
    var crypto = require("crypto");
    var db2 = require_db();
    async function ensureAgentSessionColumns() {
      await db2.query(`
    ALTER TABLE agents
    ADD COLUMN IF NOT EXISTS session_token TEXT,
    ADD COLUMN IF NOT EXISTS session_expires TIMESTAMPTZ
  `);
    }
    async function createAgentSession2(agentId) {
      await ensureAgentSessionColumns();
      const token = crypto.randomBytes(32).toString("hex");
      const expires = new Date(Date.now() + 8 * 60 * 60 * 1e3);
      await db2.query(
        `
    UPDATE agents
    SET session_token = $1,
        session_expires = $2
    WHERE id = $3
    `,
        [token, expires, agentId]
      );
      return token;
    }
    async function verifyAgentSession({ agentId, agentEmail, token }) {
      if (!agentId && !agentEmail || !token) {
        return null;
      }
      await ensureAgentSessionColumns();
      const values = [token];
      const filters = [
        "session_token = $1",
        "session_expires > NOW()",
        "(active = TRUE OR (billing_owner IS NOT NULL AND subscription_status IN ('active', 'admin_override')))"
      ];
      if (agentId) {
        values.push(agentId);
        filters.push(`id = $${values.length}`);
      }
      if (agentEmail) {
        values.push(agentEmail);
        filters.push(`LOWER(email) = LOWER($${values.length})`);
      }
      const result = await db2.query(
        `
    SELECT id, email, name
    FROM agents
    WHERE ${filters.join(" AND ")}
    LIMIT 1
    `,
        values
      );
      return result.rows[0] || null;
    }
    module2.exports = {
      createAgentSession: createAgentSession2,
      verifyAgentSession
    };
  }
});

// functions/check_agent.js
var db = require_db();
var { hashPassword, verifyPassword } = require_passwords();
var { createAgentSession } = require_agent_auth();
var headers = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
function ok(obj) {
  return {
    statusCode: 200,
    headers,
    body: JSON.stringify({ success: true, ...obj })
  };
}
function fail(msg, code = 400, extra = {}) {
  return {
    statusCode: code,
    headers,
    body: JSON.stringify({ success: false, error: msg, ...extra })
  };
}
function isAdminOverride(...values) {
  return values.some(
    (value) => String(value || "").trim().toLowerCase() === "admin_override"
  );
}
exports.handler = async (event) => {
  try {
    if (event.httpMethod === "OPTIONS") {
      return { statusCode: 200, headers, body: "" };
    }
    if (event.httpMethod !== "POST") {
      return fail("Method Not Allowed", 405);
    }
    const { email, password } = JSON.parse(event.body || "{}");
    if (!email || !password) {
      return fail("Missing email or password.");
    }
    const result = await db.query(
      "SELECT * FROM agents WHERE LOWER(email) = LOWER($1)",
      [email.trim()]
    );
    if (!result.rows.length) {
      return fail("No account found with this email.");
    }
    const agent = result.rows[0];
    if (!agent.password_hash) {
      return fail("Agent account not set up correctly.");
    }
    const passwordCheck = await verifyPassword(password, agent.password_hash);
    const isMatch = passwordCheck.valid;
    if (!isMatch) {
      return fail("Invalid password");
    }
    if (passwordCheck.legacy) {
      await db.query(
        "UPDATE agents SET password_hash = $1 WHERE id = $2",
        [await hashPassword(password), agent.id]
      );
    }
    const agentAccessOverride = isAdminOverride(
      agent.subscription_status,
      agent.stripe_customer_id,
      agent.stripe_subscription_id
    );
    const hasValidSubscription = agentAccessOverride || agent.billing_owner !== null && agent.subscription_status === "active";
    if (!agentAccessOverride && agent.billing_owner === "agent" && !hasValidSubscription) {
      return fail(
        "Billing required",
        403,
        {
          requires_payment: true,
          agentId: agent.id,
          email: agent.email,
          message: "Activate your VitaLink Agent Access to continue."
        }
      );
    }
    const isAllowed = agentAccessOverride || agent.active === true || hasValidSubscription;
    if (!isAllowed) {
      return fail(
        "Access disabled",
        403,
        {
          requires_payment: true,
          message: "Your agency no longer covers your access. Activate your personal plan to continue."
        }
      );
    }
    const token = await createAgentSession(agent.id);
    return ok({
      token,
      agent: {
        id: agent.id,
        email: agent.email,
        name: agent.name,
        phone: agent.phone,
        npn: agent.npn,
        role: agent.role || "agent",
        active: agent.active,
        billing_owner: agent.billing_owner || null,
        subscription_status: agent.subscription_status || null,
        admin_override: agentAccessOverride
      }
    });
  } catch (err) {
    console.error(err);
    return fail("Server error");
  }
};
