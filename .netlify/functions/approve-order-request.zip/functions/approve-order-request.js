var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// functions/services/db.js
var require_db = __commonJS({
  "functions/services/db.js"(exports2, module2) {
    var { Pool } = require("pg");
    var pool = new Pool({
      connectionString: process.env.SUPABASE_URL,
      ssl: { rejectUnauthorized: false }
      // required for Supabase
    });
    var db2 = {
      query: (text, params) => pool.query(text, params)
    };
    module2.exports = db2;
  }
});

// functions/approve-order-request.js
var db = require_db();
var crypto = require("crypto");
var reply = (statusCode, obj) => ({
  statusCode,
  headers: {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "https://myvitalink.app",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  },
  body: JSON.stringify(obj)
});
exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return reply(200, {});
  }
  try {
    let body = {};
    try {
      body = JSON.parse(event.body || "{}");
    } catch {
    }
    const order_id = body.order_id || body.request_id;
    if (!order_id) {
      return reply(400, { success: false, error: "Missing order_id" });
    }
    const result = await db.query(
      `
      SELECT items
      FROM public.order_requests
      WHERE id = $1
      LIMIT 1
      `,
      [order_id]
    );
    if (!result.rows.length) {
      return reply(404, { success: false, error: "Order not found" });
    }
    const { items } = result.rows[0];
    const updateResult = await db.query(
      `
      UPDATE public.order_requests
      SET status = 'approved', approved_at = NOW()
      WHERE id = $1
      RETURNING id
      `,
      [order_id]
    );
    if (!updateResult.rows.length) {
      return reply(500, { success: false, error: "Failed to approve order" });
    }
    let parsedItems = [];
    try {
      parsedItems = typeof items === "string" ? JSON.parse(items) : items;
    } catch {
      parsedItems = [];
    }
    if (!Array.isArray(parsedItems)) {
      parsedItems = [];
    }
    const qr = [];
    for (let i = 0; i < parsedItems.length; i++) {
      const item = parsedItems[i];
      const profile_id = item.profile_id || null;
      const profile = item.profile || item.profile_name || null;
      const name = item.name || item.product || "Item";
      if (!profile_id) continue;
      const raw_token = crypto.randomBytes(32).toString("hex");
      const token_hash = crypto.createHash("sha256").update(raw_token).digest("hex");
      await db.query(
        `
        UPDATE public.profiles
        SET token_hash = $1,
            qr_revoked = false,
            updated_at = NOW()
        WHERE id = $2
        `,
        [token_hash, profile_id]
      );
      const qr_url = `https://myvitalink.app/emergency.html?token=${raw_token}`;
      qr.push({
        profile_id,
        profile,
        name,
        qr_url
      });
    }
    console.log("\u2705 TOKENS STORED IN PROFILES:", order_id, qr.length);
    return reply(200, {
      success: true,
      order_id,
      qr
    });
  } catch (err) {
    console.error("\u274C approve_order error:", err);
    return reply(500, { success: false, error: "Server error" });
  }
};
