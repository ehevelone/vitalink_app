var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// functions/services/passwords.js
var require_passwords = __commonJS({
  "functions/services/passwords.js"(exports2, module2) {
    var bcrypt = require("bcryptjs");
    var crypto = require("crypto");
    function isBcryptHash(hash) {
      return /^\$2[aby]\$\d{2}\$/.test(String(hash || ""));
    }
    function isLegacySha256Hash(hash) {
      return /^[a-f0-9]{64}$/i.test(String(hash || "").trim());
    }
    function legacySha256(password) {
      return crypto.createHash("sha256").update(String(password || "")).digest("hex");
    }
    async function verifyPassword2(password, hash) {
      const storedHash = String(hash || "").trim();
      if (!password || !storedHash) {
        return { valid: false, legacy: false };
      }
      if (isBcryptHash(storedHash)) {
        return {
          valid: await bcrypt.compare(password, storedHash),
          legacy: false
        };
      }
      if (isLegacySha256Hash(storedHash)) {
        return {
          valid: legacySha256(password) === storedHash,
          legacy: true
        };
      }
      return { valid: false, legacy: false };
    }
    async function hashPassword2(password, rounds = 12) {
      return bcrypt.hash(password, rounds);
    }
    module2.exports = {
      hashPassword: hashPassword2,
      verifyPassword: verifyPassword2
    };
  }
});

// functions/agent-login-2fa.js
var { Pool } = require("pg");
var { hashPassword, verifyPassword } = require_passwords();
var pool = new Pool({
  connectionString: process.env.SUPABASE_URL,
  ssl: { rejectUnauthorized: false }
});
exports.handler = async function(event) {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: corsHeaders(),
      body: ""
    };
  }
  try {
    if (event.httpMethod !== "POST") {
      return {
        statusCode: 405,
        headers: corsHeaders(),
        body: "Method Not Allowed"
      };
    }
    const { email, password } = JSON.parse(event.body || "{}");
    if (!email || !password) {
      return {
        statusCode: 400,
        headers: corsHeaders(),
        body: "Missing credentials"
      };
    }
    const client = await pool.connect();
    const result = await client.query(
      "SELECT id, password_hash, phone, role, name FROM rsms WHERE email = $1 AND active = true LIMIT 1",
      [email]
    );
    if (result.rows.length === 0) {
      client.release();
      return {
        statusCode: 403,
        headers: corsHeaders(),
        body: "Unauthorized"
      };
    }
    const user = result.rows[0];
    const passwordCheck = await verifyPassword(password, user.password_hash);
    const valid = passwordCheck.valid;
    if (!valid) {
      client.release();
      return {
        statusCode: 403,
        headers: corsHeaders(),
        body: "Unauthorized"
      };
    }
    if (passwordCheck.legacy) {
      await client.query(
        "UPDATE rsms SET password_hash = $1 WHERE id = $2",
        [await hashPassword(password), user.id]
      );
    }
    if (!user.phone) {
      client.release();
      return {
        statusCode: 400,
        headers: corsHeaders(),
        body: "Phone not configured for 2FA"
      };
    }
    let phone = user.phone.replace(/\D/g, "");
    if (phone.length === 10) {
      phone = "+1" + phone;
    } else if (!phone.startsWith("+")) {
      phone = "+" + phone;
    }
    client.release();
    return {
      statusCode: 200,
      headers: corsHeaders(),
      body: JSON.stringify({
        step: "firebase_2fa",
        phone,
        role: user.role,
        agent: {
          id: user.id,
          // ✅ ADD
          name: user.name || ""
        }
      })
    };
  } catch (err) {
    console.error("agent-login error:", err);
    return {
      statusCode: 500,
      headers: corsHeaders(),
      body: "Server error"
    };
  }
};
function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "https://myvitalink.app",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
}
