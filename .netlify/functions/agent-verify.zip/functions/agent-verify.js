// functions/agent-verify.js
var crypto = require("crypto");
var admin = require("firebase-admin");
var { Pool } = require("pg");
if (!admin.apps.length) {
  try {
    if (!process.env.FIREBASE_PROJECT_ID || !process.env.FIREBASE_CLIENT_EMAIL || !process.env.FIREBASE_PRIVATE_KEY) {
      console.error("\u274C FIREBASE ENV MISSING");
      throw new Error("Firebase ENV not set");
    }
    let privateKey = process.env.FIREBASE_PRIVATE_KEY;
    if (privateKey.includes("\\n")) {
      privateKey = privateKey.replace(/\\n/g, "\n");
    }
    admin.initializeApp({
      credential: admin.credential.cert({
        projectId: process.env.FIREBASE_PROJECT_ID,
        clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
        privateKey
      })
    });
    console.log("\u2705 Firebase initialized");
  } catch (err) {
    console.error("\u{1F525} Firebase init crash:", err);
    throw err;
  }
}
var pool = new Pool({
  connectionString: process.env.SUPABASE_URL,
  ssl: { rejectUnauthorized: false }
});
var corsHeaders = {
  "Access-Control-Allow-Origin": "https://myvitalink.app",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
exports.handler = async function(event) {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: corsHeaders, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: corsHeaders,
      body: "Method Not Allowed"
    };
  }
  try {
    let normalizePhone2 = function(p) {
      let digits = String(p || "").replace(/\D/g, "");
      if (digits.length === 11 && digits.startsWith("1")) {
        digits = digits.slice(1);
      }
      return digits;
    };
    var normalizePhone = normalizePhone2;
    const { idToken, email } = JSON.parse(event.body || "{}");
    if (!idToken || !email) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: "Missing data"
      };
    }
    const decoded = await admin.auth().verifyIdToken(idToken);
    if (!decoded.phone_number) {
      return {
        statusCode: 403,
        headers: corsHeaders,
        body: "Phone verification required"
      };
    }
    const client = await pool.connect();
    const result = await client.query(
      "SELECT id, phone, role FROM rsms WHERE email=$1 AND active=true LIMIT 1",
      [email]
    );
    if (result.rows.length === 0) {
      client.release();
      return {
        statusCode: 403,
        headers: corsHeaders,
        body: "Unauthorized"
      };
    }
    const user = result.rows[0];
    const dbPhone = normalizePhone2(user.phone);
    const firebasePhone = normalizePhone2(decoded.phone_number);
    console.log("DB PHONE:", dbPhone);
    console.log("FIREBASE PHONE:", firebasePhone);
    if (dbPhone !== firebasePhone) {
      client.release();
      return {
        statusCode: 403,
        headers: corsHeaders,
        body: "Phone mismatch"
      };
    }
    const sessionToken = crypto.randomBytes(24).toString("hex");
    const expires = new Date(Date.now() + 8 * 60 * 60 * 1e3);
    await client.query(
      "UPDATE rsms SET admin_session_token=$1, admin_session_expires=$2 WHERE id=$3",
      [sessionToken, expires, user.id]
    );
    client.release();
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        success: true,
        token: sessionToken,
        role: user.role
      })
    };
  } catch (err) {
    console.error("agent-verify error:", err);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: "Verification failed"
    };
  }
};
