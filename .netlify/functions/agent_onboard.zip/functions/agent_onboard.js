var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// functions/services/db.js
var require_db = __commonJS({
  "functions/services/db.js"(exports2, module2) {
    var { Pool } = require("pg");
    var pool = new Pool({
      connectionString: process.env.SUPABASE_URL,
      ssl: { rejectUnauthorized: false }
      // required for Supabase
    });
    var db2 = {
      query: (text, params) => pool.query(text, params)
    };
    module2.exports = db2;
  }
});

// functions/agent_onboard.js
var db = require_db();
function generateUnlockCode(prefix = "AG", length = 10) {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < length; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `${prefix}-${code}`;
}
exports.handler = async (event) => {
  try {
    if (event.httpMethod === "OPTIONS") {
      return {
        statusCode: 200,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Methods": "GET, OPTIONS"
        },
        body: ""
      };
    }
    if (event.httpMethod !== "GET") {
      return {
        statusCode: 405,
        body: "Method Not Allowed"
      };
    }
    const params = event.queryStringParameters || {};
    const rsmCode = params.rsm;
    if (!rsmCode) {
      return {
        statusCode: 400,
        body: "Missing RSM enrollment code"
      };
    }
    const rsmResult = await db.query(
      `
      SELECT id, billing_active
      FROM rsms
      WHERE agent_enroll_code = $1
      LIMIT 1
      `,
      [rsmCode]
    );
    if (rsmResult.rows.length === 0) {
      return {
        statusCode: 404,
        body: "Invalid RSM enrollment code"
      };
    }
    const rsm = rsmResult.rows[0];
    if (!rsm.billing_active) {
      console.log("Enrollment blocked \u2014 billing inactive");
      return {
        statusCode: 403,
        body: "Office billing inactive. Contact your RSM."
      };
    }
    const rsmId = rsm.id;
    const unlockCode = generateUnlockCode();
    const result = await db.query(
      `
      INSERT INTO agents (
        role,
        active,
        unlock_code,
        rsm_id,
        created_at
      )
      VALUES (
        'agent',
        FALSE,
        $1,
        $2,
        NOW()
      )
      RETURNING id;
      `,
      [unlockCode, rsmId]
    );
    const agentId = result.rows[0].id;
    const redirectUrl = `https://myvitalink.app/core-node/agent_claim.html?code=${encodeURIComponent(unlockCode)}`;
    console.log("=================================");
    console.log(`\u2705 Agent Created: ${agentId}`);
    console.log(`\u{1F510} Unlock Code: ${unlockCode}`);
    console.log(`\u{1F464} Bound to RSM ID: ${rsmId}`);
    console.log(`\u{1F517} Redirecting to: ${redirectUrl}`);
    console.log("=================================");
    return {
      statusCode: 302,
      headers: {
        Location: redirectUrl
      }
    };
  } catch (err) {
    console.error("\u274C agent_onboard error:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: err.message
      })
    };
  }
};
