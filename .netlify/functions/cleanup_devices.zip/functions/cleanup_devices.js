var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// functions/services/db.js
var require_db = __commonJS({
  "functions/services/db.js"(exports2, module2) {
    var { Pool } = require("pg");
    var pool = new Pool({
      connectionString: process.env.SUPABASE_URL,
      ssl: { rejectUnauthorized: false }
      // required for Supabase
    });
    var db2 = {
      query: (text, params) => pool.query(text, params)
    };
    module2.exports = db2;
  }
});

// functions/services/admins.js
var require_admins = __commonJS({
  "functions/services/admins.js"(exports2, module2) {
    var crypto = require("crypto");
    async function ensureAdminsTable(client) {
      await client.query(`
    CREATE EXTENSION IF NOT EXISTS pgcrypto;

    CREATE TABLE IF NOT EXISTS admins (
      id uuid primary key default gen_random_uuid(),
      email text not null unique,
      name text,
      phone text,
      password_hash text,
      active boolean not null default true,
      full_access boolean not null default true,
      role text not null default 'admin',
      admin_session_token text,
      admin_session_expires timestamptz,
      created_at timestamptz not null default now(),
      updated_at timestamptz not null default now()
    );

    ALTER TABLE admins
    ADD COLUMN IF NOT EXISTS name text,
    ADD COLUMN IF NOT EXISTS phone text,
    ADD COLUMN IF NOT EXISTS password_hash text,
    ADD COLUMN IF NOT EXISTS active boolean not null default true,
    ADD COLUMN IF NOT EXISTS full_access boolean not null default true,
    ADD COLUMN IF NOT EXISTS role text not null default 'admin',
    ADD COLUMN IF NOT EXISTS admin_session_token text,
    ADD COLUMN IF NOT EXISTS admin_session_expires timestamptz,
    ADD COLUMN IF NOT EXISTS created_at timestamptz not null default now(),
    ADD COLUMN IF NOT EXISTS updated_at timestamptz not null default now();
  `);
    }
    async function findAdminByEmail(client, email) {
      await ensureAdminsTable(client);
      const result = await client.query(
        `
    SELECT id, email, name, phone, password_hash, active, full_access, role
    FROM admins
    WHERE LOWER(TRIM(email)) = LOWER(TRIM($1))
    LIMIT 1
    `,
        [email]
      );
      return result.rows[0] || null;
    }
    async function createAdminSession(client, adminId) {
      const sessionToken = crypto.randomBytes(32).toString("hex");
      const expires = new Date(Date.now() + 8 * 60 * 60 * 1e3);
      await client.query(
        `
    UPDATE admins
    SET admin_session_token = $1,
        admin_session_expires = $2,
        updated_at = NOW()
    WHERE id = $3
    `,
        [sessionToken, expires, adminId]
      );
      return { sessionToken, expires };
    }
    async function findAdminBySession(client, token) {
      await ensureAdminsTable(client);
      const result = await client.query(
        `
    SELECT id, email, name, role, active, full_access, admin_session_expires
    FROM admins
    WHERE admin_session_token = $1
    LIMIT 1
    `,
        [token]
      );
      const admin = result.rows[0];
      if (!admin) {
        return null;
      }
      if (admin.active !== true || admin.full_access !== true) {
        return null;
      }
      if (!admin.admin_session_expires || new Date(admin.admin_session_expires) < /* @__PURE__ */ new Date()) {
        return null;
      }
      return {
        ...admin,
        role: "admin",
        source: "admins"
      };
    }
    module2.exports = {
      ensureAdminsTable,
      findAdminByEmail,
      createAdminSession,
      findAdminBySession
    };
  }
});

// functions/_adminAuth.js
var require_adminAuth = __commonJS({
  "functions/_adminAuth.js"(exports2, module2) {
    var { Pool } = require("pg");
    var { findAdminBySession } = require_admins();
    var pool = new Pool({
      connectionString: process.env.SUPABASE_URL,
      ssl: { rejectUnauthorized: false }
    });
    async function requireAdmin2(event) {
      try {
        const token = event.headers["x-admin-session"] || event.headers["X-Admin-Session"];
        if (!token) {
          return { error: "Missing session token" };
        }
        const client = await pool.connect();
        const adminSession = await findAdminBySession(client, token);
        if (adminSession) {
          client.release();
          return { admin: adminSession };
        }
        const result = await client.query(
          "SELECT id, role, admin_session_expires FROM rsms WHERE admin_session_token=$1 LIMIT 1",
          [token]
        );
        client.release();
        if (result.rows.length === 0) {
          return { error: "Invalid session" };
        }
        const user = result.rows[0];
        if (user.role !== "admin") {
          return { error: "Not authorized" };
        }
        if (new Date(user.admin_session_expires) < /* @__PURE__ */ new Date()) {
          return { error: "Session expired" };
        }
        return { admin: user };
      } catch (err) {
        console.error("Admin auth error:", err);
        return { error: "Auth failure" };
      }
    }
    async function requireRole(event, allowedRoles) {
      try {
        const token = event.headers["x-admin-session"] || event.headers["X-Admin-Session"] || event.headers["x-rsm-token"] || event.headers["X-RSM-TOKEN"];
        if (!token) {
          return { error: "Missing session token" };
        }
        const client = await pool.connect();
        const adminSession = await findAdminBySession(client, token);
        if (adminSession) {
          client.release();
          if (!allowedRoles.includes("admin")) {
            return { error: "Not authorized" };
          }
          return { user: adminSession };
        }
        const result = await client.query(
          `
      SELECT id, email, role, billing_active, invite_code, admin_session_expires
      FROM rsms
      WHERE admin_session_token=$1
      LIMIT 1
      `,
          [token]
        );
        client.release();
        if (result.rows.length === 0) {
          return { error: "Invalid session" };
        }
        const user = result.rows[0];
        if (new Date(user.admin_session_expires) < /* @__PURE__ */ new Date()) {
          return { error: "Session expired" };
        }
        if (!allowedRoles.includes(user.role)) {
          return { error: "Not authorized" };
        }
        return { user };
      } catch (err) {
        console.error("Admin role auth error:", err);
        return { error: "Auth failure" };
      }
    }
    async function requireRsm(event) {
      const auth = await requireRole(event, ["rsm"]);
      return auth.error ? { error: auth.error } : { rsm: auth.user };
    }
    async function requireAdminOrRsm(event) {
      return requireRole(event, ["admin", "rsm"]);
    }
    module2.exports = { requireAdmin: requireAdmin2, requireRsm, requireAdminOrRsm };
  }
});

// functions/cleanup_devices.js
var db = require_db();
var { requireAdmin } = require_adminAuth();
function reply(success, obj = {}) {
  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ success, ...obj })
  };
}
exports.handler = async (event) => {
  try {
    const auth = await requireAdmin(event);
    if (auth.error) {
      return {
        statusCode: 401,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ success: false, error: "Unauthorized" })
      };
    }
    console.log("\u{1F9F9} Starting event-based device cleanup...");
    const before = await db.query(`SELECT COUNT(*) FROM user_devices`);
    console.log(`\u{1F4CA} Devices before cleanup: ${before.rows[0].count}`);
    const orphanCleanup = await db.query(`
      DELETE FROM user_devices ud
      WHERE
        (ud.user_id IS NOT NULL AND NOT EXISTS (
          SELECT 1 FROM users u WHERE u.id = ud.user_id
        ))
        OR
        (ud.agent_id IS NOT NULL AND NOT EXISTS (
          SELECT 1 FROM agents a WHERE a.id = ud.agent_id
        ))
        OR
        (ud.user_id IS NULL AND ud.agent_id IS NULL);
    `);
    console.log(`\u{1F5D1}\uFE0F Removed orphaned or dangling devices: ${orphanCleanup.rowCount}`);
    const after = await db.query(`SELECT COUNT(*) FROM user_devices`);
    console.log(`\u{1F4CA} Devices after cleanup: ${after.rows[0].count}`);
    return reply(true, {
      message: "Cleanup complete \u2705",
      removed: orphanCleanup.rowCount,
      remaining: after.rows[0].count
    });
  } catch (err) {
    console.error("\u274C cleanup_devices error:", err);
    return reply(false, { error: "Server error: " + err.message });
  }
};
