var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// functions/services/db.js
var require_db = __commonJS({
  "functions/services/db.js"(exports2, module2) {
    var { Pool: Pool2 } = require("pg");
    var pool2 = new Pool2({
      connectionString: process.env.SUPABASE_URL,
      ssl: { rejectUnauthorized: false }
      // required for Supabase
    });
    var db = {
      query: (text, params) => pool2.query(text, params)
    };
    module2.exports = db;
  }
});

// functions/services/agent-auth.js
var require_agent_auth = __commonJS({
  "functions/services/agent-auth.js"(exports2, module2) {
    var crypto = require("crypto");
    var db = require_db();
    async function ensureAgentSessionColumns() {
      await db.query(`
    ALTER TABLE agents
    ADD COLUMN IF NOT EXISTS session_token TEXT,
    ADD COLUMN IF NOT EXISTS session_expires TIMESTAMPTZ
  `);
    }
    async function createAgentSession(agentId) {
      await ensureAgentSessionColumns();
      const token = crypto.randomBytes(32).toString("hex");
      const expires = new Date(Date.now() + 8 * 60 * 60 * 1e3);
      await db.query(
        `
    UPDATE agents
    SET session_token = $1,
        session_expires = $2
    WHERE id = $3
    `,
        [token, expires, agentId]
      );
      return token;
    }
    async function verifyAgentSession2({ agentId, agentEmail, token }) {
      if (!agentId && !agentEmail || !token) {
        return null;
      }
      await ensureAgentSessionColumns();
      const values = [token];
      const filters = [
        "session_token = $1",
        "session_expires > NOW()",
        "(active = TRUE OR (billing_owner IS NOT NULL AND subscription_status IN ('active', 'admin_override')))"
      ];
      if (agentId) {
        values.push(agentId);
        filters.push(`id = $${values.length}`);
      }
      if (agentEmail) {
        values.push(agentEmail);
        filters.push(`LOWER(email) = LOWER($${values.length})`);
      }
      const result = await db.query(
        `
    SELECT id, email, name
    FROM agents
    WHERE ${filters.join(" AND ")}
    LIMIT 1
    `,
        values
      );
      return result.rows[0] || null;
    }
    module2.exports = {
      createAgentSession,
      verifyAgentSession: verifyAgentSession2
    };
  }
});

// functions/agent-toggle-client.js
var { Pool } = require("pg");
var { verifyAgentSession } = require_agent_auth();
var pool = new Pool({
  connectionString: process.env.SUPABASE_URL,
  ssl: { rejectUnauthorized: false }
});
var corsHeaders = {
  "Access-Control-Allow-Origin": "https://myvitalink.app",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: corsHeaders, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: corsHeaders,
      body: "Method Not Allowed"
    };
  }
  try {
    const client = await pool.connect();
    const body = JSON.parse(event.body || "{}");
    const userId = body.clientId || body.userId;
    const agentId = body.agentId;
    const agentSessionToken = body.agentSessionToken;
    if (!userId || !agentId) {
      client.release();
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: "Missing userId or agentId"
      };
    }
    const sessionAgent = await verifyAgentSession({
      agentId,
      token: agentSessionToken
    });
    if (!sessionAgent) {
      client.release();
      return {
        statusCode: 403,
        headers: corsHeaders,
        body: "Unauthorized"
      };
    }
    const userCheck = await client.query(
      "SELECT id, active FROM users WHERE id=$1 AND agent_id=$2 LIMIT 1",
      [userId, agentId]
    );
    if (userCheck.rows.length === 0) {
      client.release();
      return {
        statusCode: 403,
        headers: corsHeaders,
        body: "Unauthorized"
      };
    }
    const currentStatus = userCheck.rows[0].active;
    const newStatus = !currentStatus;
    await client.query(
      "UPDATE users SET active=$1 WHERE id=$2",
      [newStatus, userId]
    );
    client.release();
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        success: true,
        active: newStatus
      })
    };
  } catch (err) {
    console.error("agent-toggle-client error:", err);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: "Server error"
    };
  }
};
