var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// functions/services/db.js
var require_db = __commonJS({
  "functions/services/db.js"(exports2, module2) {
    var { Pool } = require("pg");
    var pool = new Pool({
      connectionString: process.env.SUPABASE_URL,
      ssl: { rejectUnauthorized: false }
      // required for Supabase
    });
    var db2 = {
      query: (text, params) => pool.query(text, params)
    };
    module2.exports = db2;
  }
});

// functions/encrypt.js
var require_encrypt = __commonJS({
  "functions/encrypt.js"(exports2, module2) {
    var crypto = require("crypto");
    var keyHex = process.env.ENCRYPTION_KEY;
    if (!keyHex) {
      throw new Error("ENCRYPTION_KEY not set");
    }
    var key = Buffer.from(keyHex, "hex");
    function encrypt(text) {
      const iv = crypto.randomBytes(16);
      const cipher = crypto.createCipheriv("aes-256-cbc", key, iv);
      let encrypted = cipher.update(text, "utf8", "hex");
      encrypted += cipher.final("hex");
      return iv.toString("hex") + ":" + encrypted;
    }
    function decrypt(encryptedText) {
      const parts = encryptedText.split(":");
      if (parts.length !== 2) {
        throw new Error("Invalid encrypted format");
      }
      const iv = Buffer.from(parts[0], "hex");
      const encrypted = parts[1];
      const decipher = crypto.createDecipheriv("aes-256-cbc", key, iv);
      let decrypted = decipher.update(encrypted, "hex", "utf8");
      decrypted += decipher.final("utf8");
      return decrypted;
    }
    module2.exports = {
      encrypt,
      decrypt
    };
  }
});

// functions/services/profile-share-sync.js
var require_profile_share_sync = __commonJS({
  "functions/services/profile-share-sync.js"(exports2, module2) {
    var crypto = require("crypto");
    var admin = require("firebase-admin");
    var db2 = require_db();
    var { encrypt, decrypt } = require_encrypt();
    var corsHeaders = {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Allow-Methods": "POST, OPTIONS"
    };
    function reply2(statusCode, obj) {
      return {
        statusCode,
        headers: corsHeaders,
        body: JSON.stringify(obj)
      };
    }
    function parseBody2(event) {
      return event.isBase64Encoded ? JSON.parse(Buffer.from(event.body || "", "base64").toString("utf8") || "{}") : JSON.parse(event.body || "{}");
    }
    function clean2(value) {
      const text = (value ?? "").toString().trim();
      return text || null;
    }
    function normalizeSections(sections) {
      const allowed = /* @__PURE__ */ new Set([
        "emergency",
        "medications",
        "doctors",
        "insurance_cards",
        "policies",
        "appointments"
      ]);
      const selected = Array.isArray(sections) ? sections.map((s) => clean2(s)).filter(Boolean) : [];
      const filtered = selected.filter((section) => allowed.has(section));
      return filtered.length ? [...new Set(filtered)] : ["emergency"];
    }
    async function verifyUserSession2(userId, token) {
      if (!userId || !token) return false;
      await db2.query(`
    ALTER TABLE users
    ADD COLUMN IF NOT EXISTS session_token TEXT,
    ADD COLUMN IF NOT EXISTS session_expires TIMESTAMPTZ
  `);
      const result = await db2.query(
        `
    SELECT id
    FROM users
    WHERE id = $1
      AND session_token = $2
      AND session_expires > NOW()
    LIMIT 1
    `,
        [userId, token]
      );
      return result.rows.length > 0;
    }
    async function ensureSchema2() {
      await db2.query(`
    CREATE TABLE IF NOT EXISTS profile_share_links (
      id UUID PRIMARY KEY,
      owner_user_id TEXT NOT NULL,
      recipient_user_id TEXT,
      invited_email TEXT,
      invited_phone TEXT,
      profile_id UUID,
      profile_name TEXT,
      allowed_sections JSONB NOT NULL DEFAULT '["emergency"]'::jsonb,
      status TEXT NOT NULL DEFAULT 'pending',
      invite_code TEXT UNIQUE NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      accepted_at TIMESTAMPTZ,
      revoked_at TIMESTAMPTZ
    )
  `);
      await db2.query(`
    CREATE TABLE IF NOT EXISTS profile_update_packages (
      id UUID PRIMARY KEY,
      owner_user_id TEXT NOT NULL,
      profile_id UUID,
      profile_name TEXT,
      allowed_sections JSONB NOT NULL DEFAULT '[]'::jsonb,
      encrypted_payload TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      expires_at TIMESTAMPTZ NOT NULL DEFAULT NOW() + INTERVAL '7 days'
    )
  `);
      await db2.query(`
    CREATE TABLE IF NOT EXISTS profile_update_recipients (
      id UUID PRIMARY KEY,
      package_id UUID NOT NULL REFERENCES profile_update_packages(id) ON DELETE CASCADE,
      recipient_user_id TEXT NOT NULL,
      share_link_id UUID REFERENCES profile_share_links(id) ON DELETE SET NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      notified_at TIMESTAMPTZ,
      downloaded_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
      await db2.query(`
    ALTER TABLE profile_share_links
    ALTER COLUMN owner_user_id TYPE TEXT USING owner_user_id::TEXT,
    ALTER COLUMN recipient_user_id TYPE TEXT USING recipient_user_id::TEXT
  `);
      await db2.query(`
    ALTER TABLE profile_update_packages
    ALTER COLUMN owner_user_id TYPE TEXT USING owner_user_id::TEXT
  `);
      await db2.query(`
    ALTER TABLE profile_update_recipients
    ALTER COLUMN recipient_user_id TYPE TEXT USING recipient_user_id::TEXT
  `);
      await db2.query(`
    CREATE INDEX IF NOT EXISTS idx_profile_share_links_owner
    ON profile_share_links (owner_user_id, status)
  `);
      await db2.query(`
    CREATE INDEX IF NOT EXISTS idx_profile_share_links_recipient
    ON profile_share_links (recipient_user_id, status)
  `);
      await db2.query(`
    CREATE INDEX IF NOT EXISTS idx_profile_update_recipients_user
    ON profile_update_recipients (recipient_user_id, status)
  `);
      await db2.query(`
    CREATE INDEX IF NOT EXISTS idx_profile_update_packages_expires
    ON profile_update_packages (expires_at)
  `);
    }
    async function cleanupExpiredPackages() {
      await db2.query(`
    DELETE FROM profile_update_packages
    WHERE expires_at < NOW()
       OR status = 'delivered'
  `);
    }
    function initFirebase() {
      if (admin.apps.length) return true;
      const projectId = process.env.FIREBASE_PROJECT_ID;
      const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
      let privateKey = process.env.FIREBASE_PRIVATE_KEY;
      if (!projectId || !clientEmail || !privateKey) {
        console.warn("Firebase ENV missing; profile update package created without push.");
        return false;
      }
      if (privateKey.includes("\\n")) {
        privateKey = privateKey.replace(/\\n/g, "\n");
      }
      admin.initializeApp({
        credential: admin.credential.cert({
          projectId,
          clientEmail,
          privateKey
        })
      });
      return true;
    }
    async function sendProfileUpdatePush({ recipientUserIds, packageId, profileName }) {
      if (!recipientUserIds.length || !initFirebase()) {
        return { devicesTargeted: 0, successCount: 0, failureCount: 0 };
      }
      const devicesRes = await db2.query(
        `
    SELECT id, user_id, device_token
    FROM user_devices
    WHERE user_id::TEXT = ANY($1::TEXT[])
      AND device_token IS NOT NULL
      AND TRIM(device_token) <> ''
      AND TRIM(device_token) <> 'NO_TOKEN'
    `,
        [recipientUserIds]
      );
      const seen = /* @__PURE__ */ new Set();
      const tokens = [];
      for (const row of devicesRes.rows) {
        const token = clean2(row.device_token);
        if (!token || seen.has(token)) continue;
        seen.add(token);
        tokens.push(token);
      }
      if (!tokens.length) {
        return { devicesTargeted: 0, successCount: 0, failureCount: 0 };
      }
      const response = await admin.messaging().sendEachForMulticast({
        tokens,
        notification: {
          title: "Profile update available",
          body: `${profileName || "A VitaLink profile"} has an update ready to apply.`
        },
        data: {
          route: "/profile_updates",
          type: "profile_update",
          packageId
        }
      });
      return {
        devicesTargeted: tokens.length,
        successCount: response.successCount,
        failureCount: response.failureCount
      };
    }
    async function sendProfileShareInvitePush({ recipientUserId, inviteCode, profileName }) {
      if (!recipientUserId || !inviteCode || !initFirebase()) {
        return { devicesTargeted: 0, successCount: 0, failureCount: 0 };
      }
      const devicesRes = await db2.query(
        `
    SELECT id, user_id, device_token
    FROM user_devices
    WHERE user_id::TEXT = $1
      AND device_token IS NOT NULL
      AND TRIM(device_token) <> ''
      AND TRIM(device_token) <> 'NO_TOKEN'
    `,
        [String(recipientUserId)]
      );
      const tokens = [...new Set(
        devicesRes.rows.map((row) => clean2(row.device_token)).filter(Boolean)
      )];
      if (!tokens.length) {
        return { devicesTargeted: 0, successCount: 0, failureCount: 0 };
      }
      const response = await admin.messaging().sendEachForMulticast({
        tokens,
        notification: {
          title: "Profile shared with you",
          body: `${profileName || "A VitaLink profile"} was shared with you.`
        },
        data: {
          route: "/profile_accept",
          type: "profile_share_invite",
          inviteCode
        }
      });
      return {
        devicesTargeted: tokens.length,
        successCount: response.successCount,
        failureCount: response.failureCount
      };
    }
    function createInviteCode() {
      return `VL-${crypto.randomBytes(4).toString("hex").toUpperCase()}`;
    }
    module2.exports = {
      clean: clean2,
      cleanupExpiredPackages,
      createInviteCode,
      decrypt,
      encrypt,
      ensureSchema: ensureSchema2,
      normalizeSections,
      parseBody: parseBody2,
      reply: reply2,
      sendProfileShareInvitePush,
      sendProfileUpdatePush,
      verifyUserSession: verifyUserSession2
    };
  }
});

// functions/check_device_transfer.js
var db = require_db();
var {
  clean,
  parseBody,
  reply,
  verifyUserSession
} = require_profile_share_sync();
async function cleanupExpiredTransfers() {
  await db.query(`
    DELETE FROM device_transfer_packages
    WHERE expires_at < NOW()
       OR status = 'redeemed'
  `);
}
async function ensureSchema() {
  await db.query(`
    CREATE TABLE IF NOT EXISTS device_transfer_packages (
      id UUID PRIMARY KEY,
      user_id TEXT NOT NULL,
      transfer_code TEXT UNIQUE NOT NULL,
      encrypted_payload TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      expires_at TIMESTAMPTZ NOT NULL DEFAULT NOW() + INTERVAL '6 hours',
      redeemed_at TIMESTAMPTZ
    )
  `);
  await db.query(`
    CREATE INDEX IF NOT EXISTS idx_device_transfer_code
    ON device_transfer_packages (transfer_code)
  `);
  await db.query(`
    CREATE INDEX IF NOT EXISTS idx_device_transfer_expires
    ON device_transfer_packages (expires_at)
  `);
}
exports.handler = async (event) => {
  try {
    if (event.httpMethod === "OPTIONS") return reply(200, {});
    if (event.httpMethod !== "POST") {
      return reply(405, { success: false, error: "Method Not Allowed" });
    }
    await ensureSchema();
    await cleanupExpiredTransfers();
    const body = parseBody(event);
    const userId = clean(body.userId || body.user_id);
    const sessionToken = clean(body.sessionToken);
    if (!await verifyUserSession(userId, sessionToken)) {
      return reply(403, { success: false, error: "Unauthorized" });
    }
    const transfer = await db.query(
      `
      SELECT transfer_code, expires_at
      FROM device_transfer_packages
      WHERE user_id = $1
        AND status = 'pending'
        AND expires_at > NOW()
      ORDER BY created_at DESC
      LIMIT 1
      `,
      [userId]
    );
    if (!transfer.rows.length) {
      return reply(200, {
        success: true,
        hasTransfer: false
      });
    }
    return reply(200, {
      success: true,
      hasTransfer: true,
      transferCode: transfer.rows[0].transfer_code,
      expiresAt: transfer.rows[0].expires_at
    });
  } catch (err) {
    console.error("check_device_transfer error:", err);
    return reply(500, { success: false, error: "Server error" });
  }
};
