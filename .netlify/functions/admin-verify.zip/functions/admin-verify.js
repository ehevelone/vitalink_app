var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// functions/services/admins.js
var require_admins = __commonJS({
  "functions/services/admins.js"(exports2, module2) {
    var crypto2 = require("crypto");
    async function ensureAdminsTable(client) {
      await client.query(`
    CREATE EXTENSION IF NOT EXISTS pgcrypto;

    CREATE TABLE IF NOT EXISTS admins (
      id uuid primary key default gen_random_uuid(),
      email text not null unique,
      name text,
      phone text,
      password_hash text,
      active boolean not null default true,
      full_access boolean not null default true,
      role text not null default 'admin',
      admin_session_token text,
      admin_session_expires timestamptz,
      created_at timestamptz not null default now(),
      updated_at timestamptz not null default now()
    );

    ALTER TABLE admins
    ADD COLUMN IF NOT EXISTS name text,
    ADD COLUMN IF NOT EXISTS phone text,
    ADD COLUMN IF NOT EXISTS password_hash text,
    ADD COLUMN IF NOT EXISTS active boolean not null default true,
    ADD COLUMN IF NOT EXISTS full_access boolean not null default true,
    ADD COLUMN IF NOT EXISTS role text not null default 'admin',
    ADD COLUMN IF NOT EXISTS admin_session_token text,
    ADD COLUMN IF NOT EXISTS admin_session_expires timestamptz,
    ADD COLUMN IF NOT EXISTS created_at timestamptz not null default now(),
    ADD COLUMN IF NOT EXISTS updated_at timestamptz not null default now();
  `);
    }
    async function findAdminByEmail2(client, email) {
      await ensureAdminsTable(client);
      const result = await client.query(
        `
    SELECT id, email, name, phone, password_hash, active, full_access, role
    FROM admins
    WHERE LOWER(TRIM(email)) = LOWER(TRIM($1))
    LIMIT 1
    `,
        [email]
      );
      return result.rows[0] || null;
    }
    async function createAdminSession2(client, adminId) {
      const sessionToken = crypto2.randomBytes(32).toString("hex");
      const expires = new Date(Date.now() + 8 * 60 * 60 * 1e3);
      await client.query(
        `
    UPDATE admins
    SET admin_session_token = $1,
        admin_session_expires = $2,
        updated_at = NOW()
    WHERE id = $3
    `,
        [sessionToken, expires, adminId]
      );
      return { sessionToken, expires };
    }
    async function findAdminBySession(client, token) {
      await ensureAdminsTable(client);
      const result = await client.query(
        `
    SELECT id, email, name, role, active, full_access, admin_session_expires
    FROM admins
    WHERE admin_session_token = $1
    LIMIT 1
    `,
        [token]
      );
      const admin2 = result.rows[0];
      if (!admin2) {
        return null;
      }
      if (admin2.active !== true || admin2.full_access !== true) {
        return null;
      }
      if (!admin2.admin_session_expires || new Date(admin2.admin_session_expires) < /* @__PURE__ */ new Date()) {
        return null;
      }
      return {
        ...admin2,
        role: "admin",
        source: "admins"
      };
    }
    module2.exports = {
      ensureAdminsTable,
      findAdminByEmail: findAdminByEmail2,
      createAdminSession: createAdminSession2,
      findAdminBySession
    };
  }
});

// functions/admin-verify.js
var crypto = require("crypto");
var admin = require("firebase-admin");
var { Pool } = require("pg");
var { findAdminByEmail, createAdminSession } = require_admins();
if (!admin.apps.length) {
  if (!process.env.FIREBASE_PROJECT_ID || !process.env.FIREBASE_PRIVATE_KEY || !process.env.FIREBASE_CLIENT_EMAIL) {
    console.error("\u274C Missing Firebase environment variables");
    throw new Error("Firebase config missing");
  }
  admin.initializeApp({
    credential: admin.credential.cert({
      projectId: process.env.FIREBASE_PROJECT_ID,
      privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, "\n"),
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL
    })
  });
}
var pool = new Pool({
  connectionString: process.env.SUPABASE_URL,
  ssl: { rejectUnauthorized: false }
});
var corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
exports.handler = async function(event) {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: corsHeaders, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: corsHeaders,
      body: JSON.stringify({ error: "Method Not Allowed" })
    };
  }
  try {
    let normalizePhone2 = function(p) {
      let digits = String(p || "").replace(/\D/g, "");
      if (digits.length === 11 && digits.startsWith("1")) {
        digits = digits.slice(1);
      }
      return digits;
    };
    var normalizePhone = normalizePhone2;
    let parsed;
    try {
      parsed = JSON.parse(event.body || "{}");
    } catch (e) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ error: "Invalid JSON" })
      };
    }
    const { idToken, email } = parsed;
    if (!idToken || !email) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ error: "Missing data" })
      };
    }
    const decoded = await admin.auth().verifyIdToken(idToken);
    if (!decoded.phone_number) {
      return {
        statusCode: 403,
        headers: corsHeaders,
        body: JSON.stringify({ error: "Phone verification required" })
      };
    }
    const client = await pool.connect();
    const adminUser = await findAdminByEmail(client, email);
    if (adminUser) {
      let normalizePhone3 = function(p) {
        let digits = String(p || "").replace(/\D/g, "");
        if (digits.length === 11 && digits.startsWith("1")) {
          digits = digits.slice(1);
        }
        return digits;
      };
      if (adminUser.active !== true || adminUser.full_access !== true) {
        client.release();
        return {
          statusCode: 403,
          headers: corsHeaders,
          body: JSON.stringify({ error: "Unauthorized" })
        };
      }
      const dbPhone2 = normalizePhone3(adminUser.phone);
      const firebasePhone2 = normalizePhone3(decoded.phone_number);
      if (dbPhone2 !== firebasePhone2) {
        client.release();
        return {
          statusCode: 403,
          headers: corsHeaders,
          body: JSON.stringify({ error: "Phone mismatch" })
        };
      }
      const { sessionToken: sessionToken2 } = await createAdminSession(client, adminUser.id);
      client.release();
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify({
          success: true,
          token: sessionToken2,
          role: "admin"
        })
      };
    }
    const result = await client.query(
      `
      SELECT id, phone, role
      FROM rsms
      WHERE LOWER(TRIM(email)) = LOWER($1)
        AND LOWER(role) IN ('admin', 'rsm')
        AND active = true
      LIMIT 1
      `,
      [String(email || "").trim()]
    );
    if (result.rows.length === 0) {
      client.release();
      return {
        statusCode: 403,
        headers: corsHeaders,
        body: JSON.stringify({ error: "Unauthorized" })
      };
    }
    const user = result.rows[0];
    const dbPhone = normalizePhone2(user.phone);
    const firebasePhone = normalizePhone2(decoded.phone_number);
    if (dbPhone !== firebasePhone) {
      client.release();
      return {
        statusCode: 403,
        headers: corsHeaders,
        body: JSON.stringify({ error: "Phone mismatch" })
      };
    }
    const sessionToken = crypto.randomBytes(24).toString("hex");
    const expires = new Date(Date.now() + 8 * 60 * 60 * 1e3);
    await client.query(
      "UPDATE rsms SET admin_session_token=$1, admin_session_expires=$2 WHERE id=$3",
      [sessionToken, expires, user.id]
    );
    client.release();
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        success: true,
        token: sessionToken,
        role: user.role
      })
    };
  } catch (err) {
    console.error("admin-verify error:", err);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: "Verification failed" })
    };
  }
};
