var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// functions/services/db.js
var require_db = __commonJS({
  "functions/services/db.js"(exports2, module2) {
    var { Pool } = require("pg");
    var pool = new Pool({
      connectionString: process.env.SUPABASE_URL,
      ssl: { rejectUnauthorized: false }
      // required for Supabase
    });
    var db2 = {
      query: (text, params) => pool.query(text, params)
    };
    module2.exports = db2;
  }
});

// functions/services/passwords.js
var require_passwords = __commonJS({
  "functions/services/passwords.js"(exports2, module2) {
    var bcrypt = require("bcryptjs");
    var crypto2 = require("crypto");
    function isBcryptHash(hash) {
      return /^\$2[aby]\$\d{2}\$/.test(String(hash || ""));
    }
    function isLegacySha256Hash(hash) {
      return /^[a-f0-9]{64}$/i.test(String(hash || "").trim());
    }
    function legacySha256(password) {
      return crypto2.createHash("sha256").update(String(password || "")).digest("hex");
    }
    async function verifyPassword2(password, hash) {
      const storedHash = String(hash || "").trim();
      if (!password || !storedHash) {
        return { valid: false, legacy: false };
      }
      if (isBcryptHash(storedHash)) {
        return {
          valid: await bcrypt.compare(password, storedHash),
          legacy: false
        };
      }
      if (isLegacySha256Hash(storedHash)) {
        return {
          valid: legacySha256(password) === storedHash,
          legacy: true
        };
      }
      return { valid: false, legacy: false };
    }
    async function hashPassword2(password, rounds = 12) {
      return bcrypt.hash(password, rounds);
    }
    module2.exports = {
      hashPassword: hashPassword2,
      verifyPassword: verifyPassword2
    };
  }
});

// functions/check_user.js
var db = require_db();
var crypto = require("crypto");
var { hashPassword, verifyPassword } = require_passwords();
var headers = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
function reply(success, obj = {}, code = 200) {
  return {
    statusCode: code,
    headers,
    body: JSON.stringify({ success, ...obj })
  };
}
async function ensureUserSessionColumns() {
  await db.query(`
    ALTER TABLE users
    ADD COLUMN IF NOT EXISTS session_token TEXT,
    ADD COLUMN IF NOT EXISTS session_expires TIMESTAMPTZ
  `);
}
async function createUserSession(userId) {
  const token = crypto.randomBytes(32).toString("hex");
  const expires = new Date(Date.now() + 180 * 24 * 60 * 60 * 1e3);
  await db.query(
    `
    UPDATE users
    SET session_token = $1,
        session_expires = $2
    WHERE id = $3
    `,
    [token, expires, userId]
  );
  return token;
}
exports.handler = async (event) => {
  try {
    if (event.httpMethod === "OPTIONS") {
      return { statusCode: 200, headers, body: "" };
    }
    if (event.httpMethod !== "POST") {
      return reply(false, { error: "Method Not Allowed" }, 405);
    }
    await ensureUserSessionColumns();
    const { email, password, device_id, replace } = JSON.parse(event.body || "{}");
    console.log("DEVICE RECEIVED:", device_id);
    if (!email || !password) {
      return reply(false, { error: "Email and password required" }, 400);
    }
    const result = await db.query(
      `SELECT id, email, password_hash, first_name, last_name, agent_id
       FROM users
       WHERE LOWER(email) = LOWER($1)
       LIMIT 1`,
      [email.trim()]
    );
    if (!result.rows.length) {
      return reply(false, { error: "User not found" }, 404);
    }
    const user = result.rows[0];
    const passwordCheck = await verifyPassword(password, user.password_hash);
    const valid = passwordCheck.valid;
    if (!valid) {
      return reply(false, { error: "Invalid password" }, 401);
    }
    if (passwordCheck.legacy) {
      await db.query(
        `
        UPDATE users
        SET password_hash = $1
        WHERE id = $2
        `,
        [await hashPassword(password), user.id]
      );
    }
    if (!user.agent_id && device_id) {
      const deviceResult = await db.query(
        `SELECT id, device_id
         FROM user_devices
         WHERE user_id = $1
         LIMIT 1`,
        [user.id]
      );
      if (!deviceResult.rows.length) {
        await db.query(
          `INSERT INTO user_devices (user_id, device_id, created_at, updated_at)
           VALUES ($1, $2, NOW(), NOW())`,
          [user.id, device_id]
        );
      } else {
        const existingDevice = deviceResult.rows[0].device_id;
        if (!existingDevice) {
          await db.query(
            `UPDATE user_devices
             SET device_id = $1, updated_at = NOW()
             WHERE user_id = $2`,
            [device_id, user.id]
          );
        } else if (existingDevice !== device_id) {
          if (replace === true) {
            await db.query(
              `UPDATE user_devices
               SET device_id = $1, updated_at = NOW()
               WHERE user_id = $2`,
              [device_id, user.id]
            );
          } else {
            return reply(false, { error: "DEVICE_ACTIVE" }, 403);
          }
        }
      }
    }
    const sessionToken = await createUserSession(user.id);
    return reply(true, {
      user: {
        id: user.id,
        email: user.email,
        firstName: user.first_name,
        lastName: user.last_name,
        agent_id: user.agent_id,
        session_token: sessionToken
      }
    });
  } catch (err) {
    console.error("\u274C check_user error:", err);
    return reply(false, { error: "Server error" }, 500);
  }
};
