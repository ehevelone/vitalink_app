var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// functions/services/db.js
var require_db = __commonJS({
  "functions/services/db.js"(exports2, module2) {
    var { Pool } = require("pg");
    var pool = new Pool({
      connectionString: process.env.SUPABASE_URL,
      ssl: { rejectUnauthorized: false }
      // required for Supabase
    });
    var db2 = {
      query: (text, params) => pool.query(text, params)
    };
    module2.exports = db2;
  }
});

// functions/services/user-auth.js
var require_user_auth = __commonJS({
  "functions/services/user-auth.js"(exports2, module2) {
    var db2 = require_db();
    async function verifyUserSession2(userId, token) {
      if (!userId || !token) return false;
      await db2.query(`
    ALTER TABLE users
    ADD COLUMN IF NOT EXISTS session_token TEXT,
    ADD COLUMN IF NOT EXISTS session_expires TIMESTAMPTZ
  `);
      const result = await db2.query(
        `
    SELECT id
    FROM users
    WHERE id = $1
      AND session_token = $2
      AND session_expires > NOW()
    LIMIT 1
    `,
        [userId, token]
      );
      return result.rows.length > 0;
    }
    module2.exports = {
      verifyUserSession: verifyUserSession2
    };
  }
});

// functions/claim_assisted_onboarding.js
var crypto = require("crypto");
var db = require_db();
var { verifyUserSession } = require_user_auth();
function reply(statusCode, obj) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "POST, OPTIONS"
    },
    body: JSON.stringify(obj)
  };
}
function clean(value) {
  const text = (value ?? "").toString().trim();
  return text || null;
}
function hashCode(code) {
  return crypto.createHash("sha256").update(String(code || "").trim().toUpperCase()).digest("hex");
}
exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") return reply(200, {});
  if (event.httpMethod !== "POST") {
    return reply(405, { success: false, error: "Method not allowed" });
  }
  try {
    const body = JSON.parse(event.body || "{}");
    const code = clean(body.code || body.onboardingCode)?.toUpperCase();
    const userId = clean(body.userId || body.user_id);
    const sessionToken = clean(body.sessionToken);
    if (!code || !userId || !sessionToken) {
      return reply(400, {
        success: false,
        error: "Missing onboarding code or user session"
      });
    }
    if (!await verifyUserSession(userId, sessionToken)) {
      return reply(403, { success: false, error: "Unauthorized" });
    }
    await db.query(`
      DELETE FROM assisted_client_onboarding
      WHERE expires_at <= NOW()
        AND claimed_at IS NULL
    `);
    const result = await db.query(
      `
      DELETE FROM assisted_client_onboarding
      WHERE invite_code_hash = $1
        AND claimed_at IS NULL
        AND expires_at > NOW()
      RETURNING id
      `,
      [hashCode(code)]
    );
    if (!result.rows.length) {
      return reply(404, {
        success: false,
        error: "This onboarding session has expired and cannot be reopened."
      });
    }
    return reply(200, {
      success: true,
      claimed: true
    });
  } catch (err) {
    console.error("claim_assisted_onboarding error:", err);
    return reply(500, { success: false, error: err.message });
  }
};
