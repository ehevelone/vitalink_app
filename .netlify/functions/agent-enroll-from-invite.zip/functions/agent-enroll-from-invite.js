// functions/agent-enroll-from-invite.js
var { Pool } = require("pg");
var pool = new Pool({
  connectionString: process.env.SUPABASE_URL,
  ssl: { rejectUnauthorized: false }
});
var SITE = "https://myvitalink.app";
function generateAgentCode(prefix = "AGT", length = 8) {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < length; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `${prefix}-${code}`;
}
exports.handler = async function(event) {
  if (event.httpMethod === "GET") {
    const rsmCode = event.queryStringParameters?.rsm;
    if (!rsmCode) {
      return {
        statusCode: 302,
        headers: { Location: `${SITE}` }
      };
    }
    const client = await pool.connect();
    try {
      const rsm = await client.query(
        `SELECT id
         FROM rsms
         WHERE invite_code = $1
         AND role = 'rsm'
         AND active = true
         LIMIT 1`,
        [rsmCode]
      );
      if (rsm.rows.length === 0) {
        return {
          statusCode: 302,
          headers: { Location: `${SITE}` }
        };
      }
      const rsmId = rsm.rows[0].id;
      const agentCode = generateAgentCode();
      await client.query(
        `INSERT INTO agents
          (unlock_code, active, role, rsm_id, created_at)
         VALUES
          ($1, false, 'agent', $2, NOW())`,
        [
          agentCode,
          rsmId
        ]
      );
      return {
        statusCode: 302,
        headers: {
          Location: `${SITE}/core-node/agent_enrolled.html?code=${agentCode}`
        }
      };
    } catch (err) {
      console.error("agent-enroll-from-invite error:", err);
      return {
        statusCode: 302,
        headers: { Location: `${SITE}` }
      };
    } finally {
      client.release();
    }
  }
  return {
    statusCode: 405,
    body: "Method Not Allowed"
  };
};
