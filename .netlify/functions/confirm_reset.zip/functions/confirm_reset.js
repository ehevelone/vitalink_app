var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// functions/services/db.js
var require_db = __commonJS({
  "functions/services/db.js"(exports2, module2) {
    var { Pool } = require("pg");
    var pool = new Pool({
      connectionString: process.env.SUPABASE_URL,
      ssl: { rejectUnauthorized: false }
      // required for Supabase
    });
    var db2 = {
      query: (text, params) => pool.query(text, params)
    };
    module2.exports = db2;
  }
});

// functions/services/passwords.js
var require_passwords = __commonJS({
  "functions/services/passwords.js"(exports2, module2) {
    var bcrypt = require("bcryptjs");
    var crypto = require("crypto");
    function isBcryptHash(hash) {
      return /^\$2[aby]\$\d{2}\$/.test(String(hash || ""));
    }
    function isLegacySha256Hash(hash) {
      return /^[a-f0-9]{64}$/i.test(String(hash || "").trim());
    }
    function legacySha256(password) {
      return crypto.createHash("sha256").update(String(password || "")).digest("hex");
    }
    async function verifyPassword(password, hash) {
      const storedHash = String(hash || "").trim();
      if (!password || !storedHash) {
        return { valid: false, legacy: false };
      }
      if (isBcryptHash(storedHash)) {
        return {
          valid: await bcrypt.compare(password, storedHash),
          legacy: false
        };
      }
      if (isLegacySha256Hash(storedHash)) {
        return {
          valid: legacySha256(password) === storedHash,
          legacy: true
        };
      }
      return { valid: false, legacy: false };
    }
    async function hashPassword2(password, rounds = 12) {
      return bcrypt.hash(password, rounds);
    }
    module2.exports = {
      hashPassword: hashPassword2,
      verifyPassword
    };
  }
});

// functions/confirm_reset.js
var db = require_db();
var { hashPassword } = require_passwords();
exports.handler = async (event) => {
  try {
    const { email, code, newPassword } = JSON.parse(event.body || "{}");
    if (!email || !code || !newPassword) {
      return {
        statusCode: 400,
        body: JSON.stringify({ success: false, error: "Missing fields" })
      };
    }
    const result = await db.query("SELECT * FROM agents WHERE email=$1 AND reset_code=$2", [
      email,
      code
    ]);
    if (!result.rows.length) {
      return {
        statusCode: 400,
        body: JSON.stringify({ success: false, error: "Invalid reset code" })
      };
    }
    const agent = result.rows[0];
    if (new Date(agent.reset_expires) < /* @__PURE__ */ new Date()) {
      return {
        statusCode: 400,
        body: JSON.stringify({ success: false, error: "Reset code expired" })
      };
    }
    const hashed = await hashPassword(newPassword);
    await db.query(
      `UPDATE agents 
       SET password_hash=$1, reset_code=NULL, reset_expires=NULL 
       WHERE email=$2`,
      [hashed, email]
    );
    return {
      statusCode: 200,
      body: JSON.stringify({ success: true, message: "Password reset successful \u2705" })
    };
  } catch (err) {
    console.error("\u274C confirm_reset error:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ success: false, error: err.message })
    };
  }
};
